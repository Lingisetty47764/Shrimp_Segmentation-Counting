import os
import json
import uuid
import numpy as np
from PIL import Image
from shapely.geometry import Polygon, MultiPolygon

def convert_labelme_to_coco(dataset, output_json_path):
    coco_output = {
        "images": [],
        "annotations": [],
        "categories": [{"id": 0, "name": "shrimp"}]
    }

    annotation_id = 0
    json_files = [f for f in os.listdir(dataset) if f.endswith(".json")]

    for img_id, json_file in enumerate(sorted(json_files)):
        json_path = os.path.join(dataset, json_file)
        with open(json_path) as f:
            data = json.load(f)

        image_filename = data['imagePath']
        image_path = os.path.join(dataset, image_filename)
        if not os.path.exists(image_path):
            print(f"Warning: Image file '{image_filename}' not found for JSON '{json_file}'. Skipping.")
            continue

        image = np.array(Image.open(image_path))
        height, width = image.shape[:2]
        image_id = img_id

        coco_output["images"].append({
            "id": image_id,
            "width": width,
            "height": height,
            "file_name": image_filename
        })

        instance_groups = {}
        for shape in data["shapes"]:
            group_id = shape.get("group_id") or str(uuid.uuid4())
            if group_id not in instance_groups:
                instance_groups[group_id] = []
            instance_groups[group_id].append(shape["points"])

        for polygons in instance_groups.values():
            merged_poly = None
            for pts in polygons:
                poly = Polygon(pts)
                merged_poly = poly if merged_poly is None else merged_poly.union(poly)

            if not merged_poly.is_valid:
                continue

            segmentation = []
            if isinstance(merged_poly, MultiPolygon):
                for p in merged_poly.geoms:
                    segmentation.append(np.array(p.exterior.coords).ravel().tolist())
            else:
                segmentation.append(np.array(merged_poly.exterior.coords).ravel().tolist())

            x_min, y_min, x_max, y_max = merged_poly.bounds
            area = merged_poly.area

            coco_output["annotations"].append({
                "id": annotation_id,
                "image_id": image_id,
                "category_id": 0,
                "segmentation": segmentation,
                "bbox": [x_min, y_min, x_max - x_min, y_max - y_min],
                "area": area,
                "iscrowd": 0
            })
            annotation_id += 1

    with open(output_json_path, "w") as f:
        json.dump(coco_output, f)
    print("✅ Successfully converted LabelMe to COCO format and merged masks.")