# 🦐 Shrimp Segmentation and Counting

This project performs instance segmentation and automatic counting of shrimp in images using YOLOv8.

## 🧠 Features
- LabelMe to COCO conversion with merged instance masks
- Training a YOLOv8 segmentation model
- Inference pipeline with bounding masks and shrimp counts
- Output as visual plots + CSV summary

## 🛠️ Setup

```bash
pip install -r requirements.txt
```

## 🚀 Usage

**Convert LabelMe to COCO:**
```bash
python labelme_to_coco.py
```

**Train the model:**
```bash
python train_model.py
```

**Run inference and get counts:**
```bash
python inference.py
```

## 📦 Output
- Annotated images with masks
- CSV file with shrimp counts

## 👨‍💻 Author
Lingisetty Sri Hari
[GitHub](https://github.com/Lingisetty47764)