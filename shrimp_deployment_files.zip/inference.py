import os
import cv2
import pandas as pd
from ultralytics import YOLO

def run_inference(weights_path, image_dir, output_dir, save_csv=True):
    model = YOLO(weights_path)
    os.makedirs(output_dir, exist_ok=True)
    results_data = []

    for img_name in os.listdir(image_dir):
        if img_name.endswith((".jpg", ".png")):
            img_path = os.path.join(image_dir, img_name)
            results = model(img_path)
            count = len(results[0].boxes)
            results[0].save(save_dir=output_dir)
            results_data.append({"image": img_name, "shrimp_count": count})

    if save_csv:
        df = pd.DataFrame(results_data)
        df.to_csv(os.path.join(output_dir, "shrimp_counts.csv"), index=False)
        print("✅ Inference completed and CSV saved.")