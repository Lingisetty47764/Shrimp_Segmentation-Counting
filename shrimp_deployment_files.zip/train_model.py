from ultralytics import YOLO

def train_yolov8_seg(data_yaml, epochs=50, imgsz=640):
    model = YOLO("yolov8n-seg.pt")
    model.train(data=data_yaml, epochs=epochs, imgsz=imgsz)
    print("✅ Training completed.")